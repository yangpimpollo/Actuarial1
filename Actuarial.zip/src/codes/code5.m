###----- creando funcion kpx ------------------------------
  
  kpx <- function(type, k, x) {
    if(k<1) return(1)   #  si k vale 0 retorna 1
    P <- 1
    for (i in 0:(k-1)) { P <- P*px(type,x+i) }
    return(P) 
  }
