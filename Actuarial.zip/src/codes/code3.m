###----- creando funcion qx ------------------------------
  
  qx <- function(type, x) {
    return(data[[type]][data$age == x])
  }
  qx("HI",2)   # probando la funcion