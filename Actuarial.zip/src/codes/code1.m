### creamos nuestra funcion

  intFuc <- function(arg) {
    sup <- (arg+1)/4
    inf <- arg/4
    r <-integrate(function(t) (sup) * exp(-t*log(1.06)),
                  lower = inf,
                  upper = sup
                  )
    return(r$value / 100)
  }

  M <- 0    #  iniciamos la variable 
  
### iniciamos la recurcion
  for (i in 0:399) { M <- M + intFuc(i) }
