###----- creando funcion px ------------------------------
  
  px <- function(type, x) { return(1 - qx(type,x)) }
  px("HI",2)   # probando la funcion