###----- creando funcion k1qx ------------------------------
  
  k1qx <- function(type, k, x) { return(kpx(type,k,x)*qx(type,x+k)) }