###----- importando datos --------------------------------

  library(csv)
  data <-read.csv("tabSPP.csv",header=T,sep=";",dec=",")
  head(data)   # viendo los datos
  str(data)

###--------------------------------------------------------