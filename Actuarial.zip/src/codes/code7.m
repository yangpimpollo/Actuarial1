###----- creando funcion para whole life ------------------------------
  
  Ax_apv <- function(type, w, x, i) {
    Ax <- 0
    v <- 1 + i
    for (i in 0:(w-x-1)){
      Ax <- Ax + (v**(-(i+1))*k1qx(type,i,x))
    }
    return(Ax)
  }
