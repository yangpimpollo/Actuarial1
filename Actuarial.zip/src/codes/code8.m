###----- creando funcion para n-year term increasing annually ---------
 
  IA1xn_apv <- function(type, n, x, i) {
    IA1xn <- 0
    v <- 1 + i
    for (i in 0:(n-1)){
      IA1xn <- IA1xn + (i+1)*(v**(-(i+1))*k1qx(type,i,x))
    }
    return(IA1xn)
  }
